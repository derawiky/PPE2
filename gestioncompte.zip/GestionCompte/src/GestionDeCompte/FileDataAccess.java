/**
 * 
 */
package GestionDeCompte;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

/**
 * @author Wiky Dera
 *
 */
public class FileDataAccess {
	 private final String FILENAME = "compte.dat";// déclaration et initialisation du fichier 
	
		 
		  /**
		   * le paramettre compte est un tableau de compte 
		   * @param compte
		   */
		  public  void saveCompte (CompteBancaire[] compte ) {//cette methode permet d'écrire
			  
			  
			  try
		        {    
		          		      		      
		      FileOutputStream file = new FileOutputStream(FILENAME); 
	          ObjectOutputStream out = new ObjectOutputStream(file);
	          out.writeInt(compte.length);
	          for (int i = 0; i < compte.length; i++) {
	        	  out.writeObject(compte[i] ); // écriture du tableau de compte  dans le fichier
	          }
	           
	            out.close(); //stoppe l'écriture  
	            file.close(); //fermeture du fichier
	            System.out.println("l'objet a été sérialisé");
		        }
			  catch(IOException ex) 
		        { 
		            System.out.println("Erreur");
		            ex.printStackTrace();
		        } 
			  
			  
			  
		  }
		  
		  /**
		   * cette methode permet de renvoyer le tableau de compte
		   * @return
		   */
		  public CompteBancaire[] getCompteBancaire() {
			  
			  CompteBancaire[] tabDeCompte = null;
			  
			  
			  try
		        {    
		            // lecture de  tabDeCompte from a file 
		            FileInputStream file = new FileInputStream(FILENAME); 
		            ObjectInputStream in = new ObjectInputStream(file); 
		              
		            // Method for désérialisation of tabDeCompte 
		            
		            int length = in.readInt();
			          for (int i = 0; i < length; i++) {
			        	  tabDeCompte [i] = (CompteBancaire) in.readObject(); // lecture du tableau de compte  dans le fichier
			          }
		            in.close(); 
		            file.close(); 
		              
		            System.out.println("l'objet a été désérialisé "); 
		           
		        } 
		          
		        catch(IOException ex) 
		        { 
		        	System.out.println("Erreur"); 	
		        }
			  catch (ClassNotFoundException ex) { 
		            System.out.println("ClassNotFoundException" + 
		                                " is caught"); 
		        }
			 
			return tabDeCompte ;//retourne la valeur du tableau de compte 
			  			  
			  
		  }

}
