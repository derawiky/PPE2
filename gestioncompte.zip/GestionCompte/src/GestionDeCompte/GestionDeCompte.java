package GestionDeCompte;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JButton;
import java.awt.Color;
import javax.swing.JMenuItem;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JComboBox;
import java.awt.Font;
import com.toedter.calendar.JDateChooser;


import java.awt.event.ActionListener;
import java.io.FileOutputStream;
import java.awt.event.ActionEvent;
import javax.swing.JTextPane;

public class GestionDeCompte extends JFrame {

	private JPanel contentPane;
	private JTextField txtNom;
	private JTextField txtPrnom;
	private JTextField textField;
	private TypeCompte typeCompte ;
	private String sexe ;
	private CompteCourant[] tabCourant = new CompteCourant[100];
	private CompteJoint[] tabJoint = new CompteJoint[100];
	private CompteEpargne[]  tabEpargne=new CompteEpargne[100];
	private FileDataAccess fileDataAccess = new FileDataAccess();
	private JPanel panel_1 ;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					GestionDeCompte frame = new GestionDeCompte();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public GestionDeCompte() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 644, 499);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JMenuBar menuBar = new JMenuBar();
		menuBar.setBounds(20, 20, 579, 22);
		contentPane.add(menuBar);
		
		JMenu mnCrerUnCompte = new JMenu("Créer un compte");
		mnCrerUnCompte.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				panel_1.setVisible(true);
				repaint();
			}
		});
		menuBar.add(mnCrerUnCompte);
		
		JMenu mnAfficher = new JMenu("Afficher Compte");
		menuBar.add(mnAfficher);
		
		JMenuItem mntmTous = new JMenuItem("Tous");
		mnAfficher.add(mntmTous);
		mnAfficher.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e) {
				panel_1.setVisible(true);
				repaint();
			}
		});
		
		JMenuItem mntmParticulier = new JMenuItem("Particulier");
		mnAfficher.add(mntmParticulier);
		
		JMenu mnNewMenu = new JMenu("Type Compte");
		menuBar.add(mnNewMenu);
		
		JMenuItem mntmCourant = new JMenuItem("Courant");
		mnNewMenu.add(mntmCourant);
		
		JMenuItem mntmEpargne = new JMenuItem("Epargne");
		mnNewMenu.add(mntmEpargne);
		
		JMenuItem mntmJoint = new JMenuItem("Joint");
		mnNewMenu.add(mntmJoint);
		
		JMenu mnNewMenu_1 = new JMenu("Aide");
		menuBar.add(mnNewMenu_1);
		
		JButton btnX = new JButton("X");
		btnX.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				fileDataAccess.saveCompte(tabCourant);
			}
		});
		btnX.setForeground(Color.RED);
		menuBar.add(btnX);
		
		JPanel panel = new JPanel();
		panel.setBounds(10, 42, 610, 410);
		contentPane.add(panel);
		panel.setLayout(null);
		
		panel_1 = new JPanel();
		panel_1.setVisible(true);
		panel_1.setBounds(10, 10, 590, 235);
		panel.add(panel_1);
		panel_1.setLayout(null);
		
		JLabel lblNom = new JLabel("Nom");
		lblNom.setBounds(10, 10, 35, 13);
		panel_1.add(lblNom);
		
		txtNom = new JTextField();
		txtNom.setText("");
		txtNom.setBounds(83, 7, 155, 19);
		panel_1.add(txtNom);
		txtNom.setColumns(10);
		
		JLabel lblPrnom = new JLabel("Prénom");
		lblPrnom.setBounds(248, 10, 46, 13);
		panel_1.add(lblPrnom);
		
		txtPrnom = new JTextField();
		txtPrnom.setBounds(304, 7, 119, 19);
		panel_1.add(txtPrnom);
		txtPrnom.setColumns(10);
		
		JLabel lblSexe = new JLabel("Sexe");
		lblSexe.setBounds(248, 116, 29, 13);
		panel_1.add(lblSexe);
		
		JComboBox comboBox = new JComboBox(new String[] { "Masculin", "Féminin"});
		comboBox.addActionListener(new ActionListener(){
			
			@Override
			public void actionPerformed(ActionEvent e) {
				 sexe = (String)comboBox.getSelectedItem() ;
				
			}
		});
		comboBox.setBounds(304, 112, 119, 21);
		panel_1.add(comboBox);
		
		JLabel lblDateDeNaissance = new JLabel("Date de Naissance");
		lblDateDeNaissance.setBounds(10, 61, 109, 13);
		panel_1.add(lblDateDeNaissance);
		
		JDateChooser dateChooser = new JDateChooser();
		dateChooser.setBounds(129, 55, 109, 19);
		panel_1.add(dateChooser);
		
		JLabel lblAdresse = new JLabel("Type Compte");
		lblAdresse.setBounds(10, 116, 75, 13);
		panel_1.add(lblAdresse);
		
		JComboBox comboBox_1 = new JComboBox(TypeCompte.values());
		comboBox_1.addActionListener(new ActionListener(){
			
			@Override
			public void actionPerformed(ActionEvent e) {
				 typeCompte = (TypeCompte)comboBox_1.getSelectedItem() ;
				
			}
		});
		comboBox_1.setBounds(129, 112, 109, 21);
		panel_1.add(comboBox_1);
		
		JLabel lblAdresse_1 = new JLabel("Adresse");
		lblAdresse_1.setBounds(248, 61, 46, 13);
		panel_1.add(lblAdresse_1);
		
		textField = new JTextField();
		textField.setBounds(304, 58, 119, 19);
		panel_1.add(textField);
		textField.setColumns(10);
		
		JButton btnEnregister = new JButton("Enregister");
		btnEnregister.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			
				int index = 0 ;
				CompteBancaire compte =  CompteBancaire.creerCompte(typeCompte);
				compte.nom = txtNom.getText() ;
				compte.prenom=txtPrnom.getText() ;
				compte.adresse = textField.getText() ;
				compte.dateNaissance = dateChooser.getDate(); 
				compte.sexe =  sexe ;
				switch (typeCompte) {
				case Courant:	
					index= getIndex(tabCourant, null) ;
					if (index >= 0) {
						tabCourant[index]= (CompteCourant)compte;
					}
			
					break;
				case Joint: 
					index= getIndex(tabJoint, null) ;
					if (index >= 0) {
						tabJoint[index]= (CompteJoint)compte;
					}
		
				break;
				default:
					index= getIndex(tabEpargne, null) ;
					if (index >= 0) {
						tabEpargne[index]=(CompteEpargne) compte;
					}

					break;
				}

				
			}
		});
		btnEnregister.setFont(new Font("Bahnschrift", Font.PLAIN, 10));
		btnEnregister.setForeground(Color.BLACK);
		btnEnregister.setBounds(49, 204, 85, 21);
		panel_1.add(btnEnregister);
		
		JButton btnEffacer = new JButton("Effacer");
		btnEffacer.setForeground(new Color(0, 0, 0));
		btnEffacer.setFont(new Font("Bahnschrift", Font.PLAIN, 10));
		btnEffacer.setBounds(141, 204, 85, 21);
		panel_1.add(btnEffacer);
		
		JTextPane textPane = new JTextPane();
		textPane.setBounds(33, 33, 7, 19);
		panel_1.add(textPane);
		
		JPanel panel_2 = new JPanel();
		panel_2.setBounds(0, 10, 600, 272);
		panel.add(panel_2);
		
		
		
	}
	
	private int getIndex(CompteBancaire[] TabCompte, CompteBancaire compte ) {
		int index = -1 ;
		for (int i = 0; i < TabCompte.length; i++) {
			if (TabCompte[i] == null && compte== null ) {
				index = i ;
				break;
			}
			if (TabCompte [i]!= null && compte != null && TabCompte[i].getNoCompe().equals(compte.getNoCompe())) {
				index = i ;
				break;
			}
		}
		return index;
	} 
}
